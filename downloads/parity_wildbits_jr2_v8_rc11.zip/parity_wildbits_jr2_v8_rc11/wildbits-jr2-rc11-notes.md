
## rc11 (2026-09-04)
Adds one core fix to rc10: the mouse pointer pixel is gated on the cursor ENABLE bit
(MOUSEPTR_REG[0][0], $FEA0 bit 0). Previously the enable only gated the pointer's address
state machine, never the pixel path, and the video mixer painted any non-zero grey it was
handed - so with the cursor disabled the pointer RAM sat at address 0 and byte 0 of the
bitmap covered the top-left corner. Symptom: use a mouse, unplug it, press RESET, and a
solid white square appeared. Verified fixed on hardware.

Consequence: clearing the enable is now a TRUE hide, so vtio's auto-hide simply clears
$FEA0 bit 0 - the old park-at-X=640 workaround and its position save/restore are gone.

rc11 cores are built without the ILA debug core and with all IP regenerated from scratch.
