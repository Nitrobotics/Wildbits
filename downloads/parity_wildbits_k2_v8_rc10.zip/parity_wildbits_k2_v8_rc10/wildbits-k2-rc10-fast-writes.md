# WildBits K2 v8_rc10 — turbo fast RAM writes

**Date:** 2026-09-03  **Platform:** F256 WildBits K2 (Core2X, DIP-gated turbo)
**Status:** field-verified: boots Level 2, sprites correct, sprtest2, format /f1

## What changed

The turbo MMU's stretch design gave pure-RAM **reads** a 24-tick bus frame (8.39 MHz E) and
left every **write** at the stock 32 ticks. Three earlier attempts at fast writes (v7, v7b and
the first rc10 spin) froze at the end of the FEU's "Loading Sector" copy loop. A RAM dump of the
frozen kernel showed the L2 kernel's module validation rejecting every module: its DAT-slot
remaps (`sta/std >$FFA8`) were not taking effect when preceded by fast-written stack pushes.
The common factor of all three failures was a **shortened E-high phase after a write**.

The first rc10 spin kept the write frame at 24 ticks but gives it a **stock-length E-high**: the fast-write
decision is taken at t6 (the edge that registers the address) from live decodes, E rises at t8
instead of t16, Q runs t8..t15, and the frame wraps at t23. That spin booted.

The shipping rc10 moves the SRAM write into the **read slot**: the slot is claimed at t6 exactly like a
read, the write data is captured into a 200 MHz register at t6 (the same edge that registers the state;
measured data path 14-19 ns), WEn pulses t8..t9 (the stock 2-tick width), and the slot is released at t10
exactly like a read. The graphics engine therefore sees a fast write with the
same t5..t8 draw-time pre-emption it gets before a read. The first rc10 spin had the write in
a mid-frame slot (t13..t16) with no pre-emption, which cut in-flight sprite fetches: sprites
vanished and sprtest2 froze. The read-slot write fixed both.

IO, MMU-table, vector, flash, EXRAM and sectored-VKY writes are untouched (full 32-tick frames
with IO_Data_Valid), as are DMA, debug and bus-free cycles.

## What to expect

`wildspeed` still reports 8.89 MHz: its loop is opcode fetches only. Memory copies and fills
gain roughly 10-12%, ordinary code 3-6%, screen/disk/WiFi nothing.

## Verification (K2, 2026-09-03)

| test | result |
|---|---|
| FEU boot, Loading Sector, Level 2 boot to shell | pass |
| ILA capture of the tick ISR: RAM writes as 24t frames, IO writes 32t with IO_Data_Valid | confirmed |
| sprtest (128 sprites, 4 CLUTs), sprtest2 | pass |
| format /f1 (flash write stress through rbmem's slot window) | pass |

Remaining on the standard list: dir /f0 and /f1, mouse, wizi remote-shell soak, held-key with
WiFi traffic.

Note for sprite code: the sprite engine fetches bitmap data as 16-bit words, so a bitmap must
start on an even address; sprtest2 edition 1 had its buffers at odd offsets and showed the byte
before each bitmap as the top-left pixel (fixed in edition 2). Not a core defect.

The shipped bitstream also initializes the text foreground/background LUTs with the OS-9
palette (`mif/Text_LUT_OS9_palette.coe`), so text has colour before any software runs.

## Build notes

Sources: `source/TyVKy2K2turbo_MMU_FNX6809.v` under `TURBO_FASTWRITE` (with `CORE2X_TURBO
CORE2X_STRETCH`); `RC10_ILA` adds 21 debug taps and the shipped bitstream carries a 4096-deep
ILA on the frame machine and CPU bus (probes file `wildbits_k2_6809_v8_rc10.ltx`). Hold
clean (+0.054 ns); the only setup violators are the long-standing WiFi TX-FIFO 24->6 MHz sync
path and an ILA probe-pipeline path (observation only). The Jr2 build does not define
`TURBO_FASTWRITE`; a Jr2 fast-write core is a separate decision.

Build note (2026-09-03 evening): a variant with the data captured at t8 and a t10..t11 pulse was built
while chasing a first-pixel error in sprtest2; that error was an odd-aligned sprite bitmap in the test
program (the sprite engine fetches 16-bit words), so the proven geometry above is what ships. The shipping
rc10 bitstream also initialises the text foreground/background colour LUTs with the OS-9 palette and
carries the ILA taps used to verify the 24-tick write frames.

## Font and palette in the core (rebuild 2026-09-03 20:55)
The rc10 bitstream now carries both of the resources OS-9 used to load into the text hardware at boot:
- text foreground/background colour LUTs initialised with the OS-9 palette (mif/Text_LUT_OS9_palette.coe);
- the regular text-screen font RAM (FONT_DP_MEM, 4,096 bytes) initialised from mif/Font_OS9_bannerfont.coe:
  font set 0 AND font set 1 = the OS-9 "font" module glyphs (bannerfont.sb); the two sets are identical (rebuild 22:3x, 2026-09-03).
So the Level 2 bootfile and the FEU bootfile no longer contain the font or palette modules; the screen shows the
OS-9 font and colours from power-on. Font set select: bit 5 of $D001 (vtio escape $1F $62 = set 0, $1F $63 = set 1).
Timing and write-slot geometry are unchanged from the 19:53 build (WNS -4.127 on the SID oscillator path, hold +0.054).
