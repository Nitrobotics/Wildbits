# RP2040 USB Controller

Launch `launch.bat`. Select Auto RP2040 or a specific COM port and click Connect
before power-cycling the K2. Only the RP2040 USB console is needed; do not use the
K2 debugger/DriveWire FTDI ports. Close other readers of that USB console first.

The application reconnects after USB disconnects, timestamps and saves every
received line in logs/, and displays each boot's context, image source,
configuration result and programming time. Record OS-9 booted/failed manually:
configuration accepted is not proof of a running OS. Select a table row to mark
an earlier boot, otherwise the latest one is marked. Clear display does not erase
the log or boot records. Save log copy exports the complete session log.

Current manager firmware 1.16 dbg_wait10 has USB diagnostic OUTPUT only; no USB
command parser exists. Raw transmit is disabled by default and, when explicitly
enabled, sends text with CR/LF without claiming it executes commands. The /rp
mailbox used by the OS-9 fpga command is a separate interface. No flashing,
reconfiguration, firmware update or OS debugger operations are implemented here.

Compile with `powershell -ExecutionPolicy Bypass -File build.ps1`. Uses Java Swing
and jSerialComm 2.11.4 (https://fazecast.github.io/jSerialComm/). The build fetches
the pinned dependency from Maven Central and checks its published SHA-256.
The installed JDK 21 builds Java 14 compatible classes. No firmware is changed.
