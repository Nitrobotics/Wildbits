@echo off
set "APP=%~dp0"
set "JAVA=javaw.exe"
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javaw.exe" set "JAVA=%JAVA_HOME%\bin\javaw.exe"
start "RP2040 USB Controller" "%JAVA%" -Drp2040.home="%APP%." -cp "%APP%RP2040USBController.jar;%APP%lib\jSerialComm-2.11.4.jar" Rp2040Console
