RP2040 firmware for K2 hardware only; Jr2 has no onboard RP2040.
Use B0C or B3B firmware matching your K2 board revision.
*_upgraded.uf2 is the latest diagnostic firmware. The B0C version
passed Roger's 14 reported boots, including boots 10-14 without USB.
B3B is included but has not received that hardware test.
*_original.uf2 is the unchanged firmware from the programming-guide ZIP.
Follow program_the_rp2040.txt and Rp2040-cable.jpg.
This diagnostic firmware waits up to 10 seconds for the USB console
before startup. Without USB, expect the full timeout.
See BUILD.txt for the firmware build settings.
Java USB console: open JavaDebug/launch.bat (Java 14 or newer required).
