# WildBits Jr2 core rc12 - the VS1053 (MP3 / MIDI) chip becomes usable

rc12 = rc11 (video-lottery constraints, SRAM strobe/hold constraints, FASTWR_LATE2 write slot, mouse-pointer gate,
MIDI control register ed.2) plus the reworked FPGA bridge in front of the VS1053b sound chip at $FF50, the same
bridge the K2 rc12 core carries, and two Jr2-only fixes. Timing: WNS +0.188 ns, WHS +0.029 ns, no failing endpoints.

## What was wrong on the Jr2
- The IO-page module handed the bridge the full $5x address instead of the register offset, so every write to
  $FF50-$FF57 was ignored: no command ever started and reads returned unwritten registers. The chip could not have
  worked on any earlier Jr2 core.
- The chip was clocked with the raw 24.576 MHz, outside its 12-13 MHz boot range. It now gets 24.576 / 2 like the K2.
- A hold path from the video-mode resynchronizer into the 25 MHz video clock was left untimed; the K2 waiver is now
  in the Jr2 constraints too.

## The bridge (shared with the K2 rc12)
- SPI at IO_Clk/16 = 1.57 MHz by default; CTRL bit 2 (VS_FAST) restores IO_Clk/4 once CLOCKF is up.
- Exactly 32 clocks per SCI command, 8 per SDI byte; DREQ through a two-flop synchronizer.
- $FF52/$FF53 = data high/low (big-endian); $FF54 read snapshots the 11-bit FIFO count for $FF55.
- CTRL bit 3 (VS_RESET) drives the chip's XRESET low, idles the bit engine and flushes the SDI FIFO.

Register map: $FF50 CTRL (b0 START, b1 READ, b2 FAST, b3 RESET, b7 BUSY), $FF51 SCI register, $FF52/53 data,
$FF54/55 FIFO status + count, $FF57 SDI FIFO port. Equates are in wildbits.d (VS1053.Base, VS_*).

## The Jr2 boot strap
One Jr2 PCB run ties the chip's GPIO1 (pin 34) to VCC, which makes the VS1053 boot as a real-time MIDI synthesizer
that decodes nothing. There is no FPGA pin on that strap, so no core can change it. The board-level fix from the Jr2
author is a solder bridge from pin 33 (GPIO0) to pin 34: GPIO0 high makes the chip try an SPI boot first, find no
EEPROM and run the normal stream decoder. "vs -i" shows the pins: GPIO0 = 1 is the bridged, decoding state.

## On the disk
- vs (wb/vs1053, edition 7): "vs -s file" plays mp3, ogg, wav, aac, wma and format 0 mid and is silent unless
  "-d" asks for the readouts; "vs -t" sine test, "vs" test chain, "vs -m" memory self-test, "vs -r" reset,
  "vs -i" chip state and GPIO pins, "vs -v hh" volume, "vs -c hh" clock, "vs -g" GBUF off, "vs -b" background,
  "vs -?" help. A .mid that is not format 0 is reported. "vs -w" needs the K2 rc13 strap register and reports so here.
- SOUNDS directory with sample files. MIDI needs the 4.5x clock ("vs -s" sets it for .mid); MP3 streams at 3.5x.
- vtio InitCODEC selects all five WM8776 analog inputs (R21 = $1F): the VS1053 sits on AIN3..5.

## Cores
Jr2 rc12 built 2026-09-06 12:33 (wildbits_jr2_6809_v8_rc12.mcs in this kit). K2 rc12 built 2026-09-05 23:06.
