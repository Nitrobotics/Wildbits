# WildBits K2 core rc12 - the VS1053 (MP3 / MIDI) chip becomes usable

rc12 = rc11 (FASTWR_LATE2 write slot, MEM_A_o multicycle relaxation off, mouse-pointer gate, MIDI control register ed.2)
plus a rework of the FPGA bridge in front of the VS1053b sound chip at $FF50. Nothing else in the core changed; timing
closes on the same two synchronizer endpoints as rc11.

## What was wrong
- The bridge clocked the chip's SPI at 6.29 MHz, 3.6x the chip's boot-time SCI limit (1.76 MHz), so every command
  was over-speed until software raised CLOCKF - which nothing ever did.
- Every frame ran one clock too many (33 per SCI command, 9 per SDI byte), so reads came back shifted a bit.
- The 16-bit data pair sat low byte first, backwards for the 6809's `std`/`ldd`.
- The FIFO count could tear across a 16-bit read.
- A chip that hung with DREQ low could not be reset from software: every SCI command waits for DREQ, and the chip's
  XRESET pin was wired straight to the board's cold reset.

## What rc12 does
- SPI at IO_Clk/16 = 1.57 MHz by default; CTRL bit 2 (VS_FAST) restores IO_Clk/4 once CLOCKF is up.
- Exactly 32 clocks per SCI command, 8 per SDI byte; DREQ through a two-flop synchronizer.
- $FF52/$FF53 = data high/low (big-endian); $FF54 read snapshots the 11-bit FIFO count for $FF55.
- CTRL bit 3 (VS_RESET) drives the chip's XRESET low, idles the bit engine and flushes the SDI FIFO.

Register map: `$FF50` CTRL (b0 START, b1 READ, b2 FAST, b3 RESET, b7 BUSY), `$FF51` SCI register, `$FF52/53` data,
`$FF54/55` FIFO status + count, `$FF57` SDI FIFO port. Equates are in `wildbits.d` (VS1053.Base, VS_*).

## On the disk
- `vs` (wb/vs1053): test chain, `vs -t` sine test, `vs -s file` player (mp3, ogg, wav, aac, wma, format 0 mid),
  `vs -m` memory self-test, `vs -r` reset, `vs -v hh` volume, `vs -c hh` clock, `vs -g` GBUF buffer off, `vs -?` help.
- `SOUNDS` directory with sample files. MIDI needs the 4.5x clock (`vs -s` sets it for .mid); MP3 streams at 3.5x.
- vtio's InitCODEC now selects all five WM8776 analog inputs (R21 = $1F, as Foenix's own init does): the VS1053 sits
  on AIN3..5 and was silent with the old $03.

## Cores
K2 rc12 built 2026-09-05 23:06. The Jr2 core has not been rebuilt with the bridge changes yet (shared source; its top
and IO-page module carry the same reset wiring).
