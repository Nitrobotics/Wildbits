RC20 (K2, core built 2026-09-28 11:39, WNS +0.005 / WHS +0.053): DMA logic operations fixed.

Also in rc20: no byte dropped at the vertical-blank hand-off, the first byte of a transfer no longer stale, op fills reach their last byte, byte copies between even and odd addresses land on the right SRAM lane. Proven with dmaxfer ed.4 (UME/dmaxfer on the ume disk) and the engine simulation in wildbits-buildkit/fpga/sim/dma.

Everything else is rc19: Turbo mode (12MHz), the rc16 MMU register-window RAM inhibit, the rc17 line drawer and DMA handshake.
