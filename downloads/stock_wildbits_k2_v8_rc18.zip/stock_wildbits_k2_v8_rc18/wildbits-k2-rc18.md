RC18 includes UART baud timing and reset-sequencing improvements, fixed $FF9x sound aliases (legacy $C4 remains), and the rc17 DMA/line-engine improvements.
K2 additionally includes the RP2040 supervisor mailbox at $FE78-$FE7F and $FE88-$FE8F.
