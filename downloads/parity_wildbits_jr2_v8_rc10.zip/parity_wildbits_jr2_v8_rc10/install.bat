@echo off
REM Reprogram the Jr2 flash: FEU /f0 blocks (f0-f4) + booter blocks (booter_0-2)
REM Run from inside this folder. Jr2 FoenixMgr debug port = COM4

python ../fnxmgr.py --port COM4 --flash-bulk bulk.csv
