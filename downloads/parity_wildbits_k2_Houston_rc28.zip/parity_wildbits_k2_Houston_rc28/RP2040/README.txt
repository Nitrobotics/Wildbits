RP2040 firmware for K2 hardware only; Jr2 has no onboard RP2040.
Use B0C or B3B firmware matching your K2 board revision.
*_upgraded.uf2 is the latest diagnostic firmware. The B0C version
passed Roger's 14 reported boots, including boots 10-14 without USB.
B3B is included but has not received that hardware test.
*_original.uf2 is the unchanged firmware from the programming-guide ZIP.
Follow program_the_rp2040.txt and Rp2040-cable.jpg.
This diagnostic firmware waits up to 10 seconds for the USB console
before startup. Without USB, expect the full timeout.
See BUILD.txt for the firmware build settings.
fpga_mgr_B0C_4xAnyMB.uf2 is firmware 1.16 for B0C boards. A core may span
flash slots, and it waits 2 seconds at startup.
fpga_mgr_B0C_117_nitrobotics.uf2 is firmware 1.17 for B0C boards, with a
2-second startup wait. It has not received the boot test above.
Before installing 1.17, set the back-panel switches to context 1 or 4:
it reads old flash slots as 2 MiB each, so a core over 2 MiB stored by
older firmware no longer boots. Afterward use fpga fwipe N and fpga flash N
on the Future disk to store those contexts again. Once the flash has been
converted, do not go back to older firmware.
Java USB console: open JavaDebug/launch.bat (Java 14 or newer required).
