Wildbits K2 parity kit

This kit contains one FPGA core and two NitrOS-9 Level 2 disks:
  wildbitsk2_stock.dsk  - main-branch OS build
  wildbitsk2_future.dsk - main plus the enabled overlays

Choose either disk for your machine. Overlay features are on Future.
The core is shared by both disk editions. Core files retain their build dates.

FEU / booter installation (does not install the FPGA core or Level 2 disk):
  install.bat       uses the Future FEU blocks in this folder.
  install-stock.bat uses the Stock FEU blocks in stock-feu/.
Run either batch file from this kit folder, beside the FoenixMgr tools
in its parent folder. Check the serial port in the selected batch file
before running it. Do not combine blocks from the two FEU sets.

RP2040/ includes firmware, instructions, photos and the Java USB console.
The RP2040 firmware is for K2 hardware; it is bundled with both kits
for convenience. Jr2 has no onboard RP2040.
