# WildBits K2 v8_rc11 — Jr2 write-slot geometry, MIDI control register, mouse pointer gate

Built 2026-09-05 11:21 from the shared turbo MMU (`TyVKy2K2turbo_MMU_FNX6809.v`) with
`TURBO_FASTWRITE FASTWR_LATE FASTWR_LATE2`, no ILA, every IP run rebuilt. Hardware verification
was still pending when this kit was assembled — treat it as a test kit until the WildBits page
links it.

## Write slot: three ticks of address setup (FASTWR_LATE2)
The fast RAM write now strobes WEn at t9..t11 with the SRAM slot released at t12 — the geometry
proven on the Jr2 rc11 — instead of the rc10 t7..t9 / release t10. Both machines carry the same
SRAM (ISSI IS61WV102416FBLL-8BLI, 1M x 16, 8 ns, zero address-setup requirement of its own); the
margin is for the FPGA's address-output path, which is not timed against WEn by the constraints.
On the Jr2 one tick of setup wrote to the graphics engine's stale address (black layers), two
ticks left occasional stray writes (sparklies); the K2's board has run on one tick, but the
DriveWire error-244s that began with rc10's fast writes fit the same mechanism at a low rate.
This build also disables the K2 constraints file's multicycle relaxation on MEM_A_o, which let
the address path be routed slow.
Expect a small drop in `wildspeed`'s write figure against rc10 (the strobe is two ticks later).

## Also in this core
- Mouse pointer pixel gated on the enable bit: no solid block after a reset with the mouse
  unplugged; a true hide, so vtio no longer parks the pointer off-screen.
- MIDI control register ($FF30) edition 2: offset 0 reads Tx-FIFO-empty in bit 3 and Rx-FIFO-empty
  in bit 2; bit 1 resets both FIFOs (write it back to 0 to release). Full address decode, FIFO
  reset-busy gating, resynchronised flags.
- OS-9 palette and bannerfont in the core, fast RAM writes, typematic engine, as rc10.

## Timing note
Two reported setup misses (WNS -4.0 ns), both 24 MHz -> 6 MHz / 25 MHz crossings landing on
synchroniser registers (the WizFi TX-FIFO IRQ sync, pre-existing since rc10, and the new MIDI
Tx-empty sync). They are unrelated-clock crossings the K2 constraints file does not yet declare
asynchronous; the SRAM and video paths are clean. To be tidied in the next constraints pass.
