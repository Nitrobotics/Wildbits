RC18 includes UART baud timing and reset-sequencing improvements, fixed $FF9x sound aliases (legacy $C4 remains), and the rc17 DMA/line-engine improvements.
Jr2 uses the verified rc18_reset build unchanged, with its board-specific SRAM timing and no ILA. No onboard RP2040.
