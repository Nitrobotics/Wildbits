# WildBits K2 core v8 rc13 (2026-09-08)

rc13 is rc12 (the VS1053 bridge core) with three fixes in the video path, one new register window and a
constraint clean-up. Built 2026-09-08 18:19 (Vivado 2025.2, Performance_ExplorePostRoutePhysOpt): WNS +0.023 ns,
WHS +0.036 ns, 0 failing endpoints - the first K2 build to close timing completely (rc12 shipped at -4.28 ns on two
synchronizer inputs, see item 5). Verified on the K2 the same evening.

## What changed

1. **Write slot unchanged: FASTWR_LATE2** (3 ticks of address setup, WEn ticks 9 to 11, release at 12), the geometry
   rc11 and rc12 ran on. A 4-tick slot (LATE3) was tried on the Jr2 the same day, put sparklies on every CPU write and
   was withdrawn before it reached the K2.
2. **Bus-grant crossing timed.** The MMU's bus grant to the video engine (Read_Valid, 200 MHz) is sampled by the
   engine on the 100 MHz A clock and decides whether a fetch lands inside the CPU's slot. The XDC had declared both
   directions of that crossing false paths, so every build placed it with a different, untimed skew: "bitmaps and
   sprites gone at boot" on some builds, sparklies on others. rc13 bounds both directions to 4.5 ns (datapath-only)
   and leaves the SRAM pins on their previous constraints. The paths close with 0.89 and 0.68 ns to spare.
3. **Fetch timeouts in the sprite and bitmap engines.** A fetch whose address counter never reports "reached" used
   to park the state machine for ever (sprite layer collapsing into bars after minutes of the 128-sprite demo, bitmap
   layer black until reset). Both machines now abandon such a fetch after about 10 to 20 microseconds: one line is
   lost, the frame goes on.
4. **Text colour LUTs readable.** The two text colour tables (foreground at $1700, background at $1740 of VICKY
   page $C0) were write-only block RAM. rc13 keeps a shadow of each and returns it on CPU reads, pre-loaded with
   the same OS-9 palette the block RAM starts with. Byte order per entry is blue, green, red, alpha.
   The `lutrd` command on the kit disk dumps every LUT.
5. **Timing report finally clean.** The two endpoints every K2 build had failed since rc6 are MIDI UART FIFO
   empty flags landing on two-flop synchronizers (WiFi interface and MIDI block). A synchronizer input is a clock
   crossing by design, so rc13 waives its first stage; the second stage stays timed. Nothing else was hiding behind
   them: the whole design now reports 0 failing endpoints.

## Notes

- The VS1053 bridge is exactly rc12's ($FF50: slow SPI by default, VS_FAST, exact frames, big-endian data, CTRL RESET).
  The strap-pin register once planned for rc13 was dropped after the 09-07 bench showed pin V1 is the chip's GPIO0;
  VS1053_MIDI_RT_o stays tied low.
- The graphics LUTs (four of 256 entries) were always readable; they start empty at power-up.
- The `sprites` demo on this kit is edition 8: an earlier loop bug in the demo itself (not the core) wrote past the
  128 sprite records into the text colour tables every frame, which is what the text-LUT read-back caught.
- Jr2 rc13 carries the same items 1 to 4; item 5 is K2-only.
